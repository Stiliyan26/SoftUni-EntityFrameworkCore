﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public static class Config
    {
        public const string ConnectionString = @"Server=STILI;Database=Bet377;Integrated Security=True;";
    }
}
