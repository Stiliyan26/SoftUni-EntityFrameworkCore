﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConncectionString = 
            @"Server=STILI;Database=ProductShop;Integrated Security=True";
    }
}
