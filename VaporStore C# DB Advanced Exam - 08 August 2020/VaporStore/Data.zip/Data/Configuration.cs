﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=STILI;Database=VaporStore;Integrated Security=True;Encrypt=False";
    }
}