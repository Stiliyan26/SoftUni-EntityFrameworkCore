﻿namespace VaporStore.DataProcessor
{ 
    using Data;
    using Microsoft.EntityFrameworkCore;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Serialization;
    using System.Linq;
    using VaporStore.Data.Models;

    public static class Serializer
    {
        public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
        {
            var gamesByGenre = context
                .Genres
                .Include(ge => ge.Games)
                .ThenInclude(g => g.Developer)
                .ToArray()
                .Where(ge => genreNames.Contains(ge.Name))
                .Select(ge => new
                {
                    Id = ge.Id,
                    Genre = ge.Name,
                    Games = ge.Games
                        .Where(ga => ga.Purchases.Any())
                        .Select(ga => new
                        {
                            Id = ga.Id,
                            Title = ga.Name,
                            Developer = ga.Developer.Name,
                            Tags = String.Join(", ", ga.GameTags.Select(gt => gt.Tag.Name)),
                            Players = ga.Purchases.Count()
                        })
                        .OrderByDescending(ga => ga.Players)
                        .ThenBy(ga => ga.Id)
                        .ToArray(),
                    TotalPlayers = ge.Games.Sum(game => game.Purchases.Count)
                })
                .OrderByDescending(ge => ge.TotalPlayers)
                .ThenBy(ge => ge.Id)
                .ToArray();
                

            string jsonString = JsonConvert.SerializeObject(gamesByGenre, Formatting.Indented);

            return jsonString;
        }

        public static string ExportUserPurchasesByType(VaporStoreDbContext context, string purchaseType)
        {
            throw new NotImplementedException();
        }
    }
}