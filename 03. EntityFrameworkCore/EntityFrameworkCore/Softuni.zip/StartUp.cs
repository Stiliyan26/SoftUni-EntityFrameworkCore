﻿using System;

namespace Softuni
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
    